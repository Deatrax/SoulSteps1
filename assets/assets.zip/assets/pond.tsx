<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="pond" tilewidth="32" tileheight="32" tilecount="225" columns="5">
 <image source="pond.png" width="190" height="190"/>
</tileset>
