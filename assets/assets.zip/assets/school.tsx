<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="school" tilewidth="32" tileheight="32" tilecount="110" columns="10">
 <image source="school.png" width="350" height="376"/>
</tileset>
