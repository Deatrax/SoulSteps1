<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="floorswalls_LRK!" tilewidth="32" tileheight="32" tilecount="1085" columns="31">
 <image source="floorswalls_LRK.png" width="1000" height="1143"/>
</tileset>
