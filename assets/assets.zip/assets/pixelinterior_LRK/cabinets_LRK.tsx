<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="cabinets_LRK" tilewidth="32" tileheight="32" tilecount="7371" columns="117">
 <image source="cabinets_LRK.png" width="3750" height="2020"/>
</tileset>
