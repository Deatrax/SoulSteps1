<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="books" tilewidth="32" tileheight="32" tilecount="225" columns="15">
 <image source="books.png" width="500" height="500"/>
</tileset>
