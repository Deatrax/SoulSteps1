<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="kitchen_LRK" tilewidth="32" tileheight="32" tilecount="2070" columns="46">
 <image source="kitchen_LRK.png" width="1500" height="1442"/>
</tileset>
