<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="asset1" tilewidth="32" tileheight="32" tilecount="198" columns="18">
 <image source="asset1.jpg" width="595" height="376"/>
</tileset>
