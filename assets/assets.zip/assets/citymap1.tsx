<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="citymap1" tilewidth="32" tileheight="32" tilecount="580" columns="29">
 <image source="Clean City Asset Pack - 2D Art.gif" width="928" height="640"/>
</tileset>
