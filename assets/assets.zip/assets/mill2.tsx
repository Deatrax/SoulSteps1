<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="mill2" tilewidth="32" tileheight="32" tilecount="64" columns="8">
 <image source="mill2.png" width="260" height="260"/>
</tileset>
