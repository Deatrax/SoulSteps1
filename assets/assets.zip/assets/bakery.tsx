<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="bakery" tilewidth="32" tileheight="32" tilecount="96" columns="12">
 <image source="bakery.jpg" width="400" height="284"/>
</tileset>
