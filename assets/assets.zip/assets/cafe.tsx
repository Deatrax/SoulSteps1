<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="cafe" tilewidth="32" tileheight="32" tilecount="64" columns="8">
 <image source="cafe.png" width="270" height="270"/>
</tileset>
