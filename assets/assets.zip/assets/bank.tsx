<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="bank" tilewidth="32" tileheight="32" tilecount="48" columns="8">
 <image source="bank.png" width="270" height="202"/>
</tileset>
