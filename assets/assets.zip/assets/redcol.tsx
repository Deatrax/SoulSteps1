<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="redcol" tilewidth="32" tileheight="32" tilecount="45" columns="9">
 <image source="red.png" width="300" height="168"/>
 <tile id="0">
  <properties>
   <property name="blocked" type="bool" value="true"/>
  </properties>
 </tile>
</tileset>
