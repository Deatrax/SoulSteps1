<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="livingroom_LRK" tilewidth="32" tileheight="32" tilecount="2542" columns="62">
 <image source="livingroom_LRK.png" width="2000" height="1333"/>
</tileset>
