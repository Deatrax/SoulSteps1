<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="playground-small" tilewidth="32" tileheight="32" tilecount="12" columns="3">
 <image source="playground-small.png" width="100" height="134"/>
</tileset>
