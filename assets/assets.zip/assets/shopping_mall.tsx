<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="shopping_mall" tilewidth="32" tileheight="32" tilecount="84" columns="12">
 <image source="shopping_mall.jpg" width="400" height="225"/>
</tileset>
