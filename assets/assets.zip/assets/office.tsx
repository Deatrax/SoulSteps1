<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="office" tilewidth="32" tileheight="32" tilecount="567" columns="21">
 <image source="office.png" width="698" height="884"/>
</tileset>
