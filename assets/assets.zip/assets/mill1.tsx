<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="mill1" tilewidth="32" tileheight="32" tilecount="64" columns="8">
 <image source="mill1.png" width="280" height="258"/>
</tileset>
