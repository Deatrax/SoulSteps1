<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="asset2" tilewidth="32" tileheight="32" tilecount="357" columns="21">
 <image source="asset2.png" width="700" height="547"/>
</tileset>
