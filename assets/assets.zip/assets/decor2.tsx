<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="decor2" tilewidth="32" tileheight="32" tilecount="225" columns="7">
 <image source="decor2.png" width="250" height="250"/>
</tileset>
