<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="redCollision" tilewidth="32" tileheight="32" tilecount="45" columns="9">
 <properties>
  <property name="blocked" type="bool" value="true"/>
 </properties>
 <image source="../../../projct/SoulSteps1/assets/red.png" width="300" height="168"/>
</tileset>
