<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="lake" tilewidth="32" tileheight="32" tilecount="35" columns="7">
 <image source="lake.png" width="230" height="187"/>
</tileset>
