<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.10" tiledversion="1.11.2" name="decorations_LRK" tilewidth="32" tileheight="32" tilecount="195" columns="15">
 <image source="decorations_LRK.png" width="500" height="417"/>
</tileset>
